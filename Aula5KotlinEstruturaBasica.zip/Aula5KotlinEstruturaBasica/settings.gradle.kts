
rootProject.name = "Aula5KotlinEstruturaBasica"

